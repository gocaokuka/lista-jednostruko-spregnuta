#include <stdio.h>
#include <stdlib.h>

typedef struct Knjiga
{
    char naslov [20];
    char pisac [30];
    int godina;

} Knjiga;

typedef struct Cvor
{
    Knjiga knjiga;
    struct Cvor* next;

}Cvor;

Cvor* head=NULL;
Cvor* tail=NULL;
int elCount=0;

Cvor* GetNoviCvor(Knjiga knjiga)
{
    Cvor* noviCvor=(Cvor*)malloc(sizeof(Cvor));
    if(noviCvor==NULL)
    {
        return NULL;
    }
noviCvor->knjiga=knjiga;
    noviCvor->next=NULL;


    return noviCvor;
}

Cvor* Dodajprvi(Knjiga knjiga)
{
    Cvor* noviCvor=GetNoviCvor(knjiga);
    if (head==NULL) tail = noviCvor;
        else noviCvor->next = head;

    head = noviCvor;
    elCount++;

    return noviCvor;
}


Cvor* Dodajposlednji(Knjiga knjiga)
{
    Cvor* noviCvor=GetNoviCvor(knjiga);

    Cvor* tmp = head;
    while(tmp->next!=NULL)
        tmp = tmp->next;
    tmp->next = noviCvor;
    tail = noviCvor;

    elCount++;

    return noviCvor;
}

Cvor* dodajCvor(int index, Knjiga knjiga)
{
    Cvor* noviCvor=GetNoviCvor(knjiga);

    if (index==0) return Dodajprvi(knjiga);
    if (index>elCount-1) return Dodajposlednji(knjiga);

    Cvor* tmp = head;
    int brojac = 0;
    while(brojac<index-1)
    {
       tmp = tmp->next;
       brojac++;
    }

    noviCvor->next = tmp->next;
    tmp->next = noviCvor;

    elCount++;

    return noviCvor;
}

void brisiPrvi() {

   Cvor *tempLink = head;

   head = head->next;
   free(tempLink);
   elCount--;
}

void brisiPoslednji()
{
    Cvor* tmp = head;
    Cvor* brisiPokazivac = NULL;
    int i;
    for(i = 0; i<elCount-2;i++) tmp = tmp->next;
    brisiPokazivac = tmp->next;
    free(brisiPokazivac);
    tmp->next = NULL;
    tail = tmp;
    elCount--;


}

void uklonitiCvor(int index)
{
    if (index==0) return brisiPrvi();
    if (index>elCount-1) return brisiPoslednji();

    Cvor* tmp = head;
    Cvor* brisiPokazivac;
    int brojac = 0;
    while(brojac<index-1)
    {
        tmp = tmp->next;
        brojac++;
    }

    brisiPokazivac = tmp->next;
    tmp->next = brisiPokazivac->next;
    free(brisiPokazivac);

    elCount--;

}

void izmenitiCvor(int index, Knjiga knjiga)
{
    Cvor* tmp = head;
    int brojac = 0;
    while(brojac<index)
    {
        tmp = tmp->next;
        brojac++;
    }

    tmp->knjiga = knjiga;

}

void ispisiListu(Cvor* headIn)
{
    Cvor* tmp = headIn;
    if (tmp==NULL) return;
    int trenutnaPozicija = 0;
    while(trenutnaPozicija<=elCount-1)
    {
        printf("%s %s %d\n",tmp->knjiga.naslov, tmp->knjiga.pisac, tmp->knjiga.godina);
        tmp = tmp->next;
        trenutnaPozicija++;
    }

    printf("\n\n");
}


int main()
{

   Knjiga prva;
   strcpy(prva.naslov,"Promeni svet");
   strcpy(prva.pisac,"Zan Cigler");
   prva.godina=2017;

   Knjiga druga;
   strcpy(druga.naslov,"Stranac u ogledalu");
   strcpy(druga.pisac,"Sidni Seldon");
   druga.godina=2016;

   Knjiga treca;
   strcpy(treca.naslov,"Sutra u zauvek");
   strcpy(treca.pisac,"Nora Roberts");
   treca.godina=2016;

   Knjiga cetvrta;
   strcpy(cetvrta.naslov,"Zamka");
   strcpy(cetvrta.pisac,"Melani Rabe");
   cetvrta.godina=2016;

    Dodajprvi(prva);
    Dodajposlednji(treca);
    dodajCvor(1,druga);
    Dodajposlednji(cetvrta);
    ispisiListu(head);

    izmenitiCvor(2,treca);
    ispisiListu(head);

    brisiPrvi();
    brisiPoslednji();
    uklonitiCvor(1);
    ispisiListu(head);


    return 0;
}
